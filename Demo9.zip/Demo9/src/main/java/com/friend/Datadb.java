package com.friend;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Datadb {
	
	public boolean chkNull(String CandName) throws SQLException
	{
		boolean bFlag = false;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jforce","root","root");
			
			String q = "select username,password, emailid, phoneNo, candidateName from admin where candidateName is null";
			
			Statement stmt =  conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(q);
			
			bFlag = rs.next();
		
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bFlag;
		
				
		
	}
	
	
	
	
	public boolean updateData(String us,String CandName) throws SQLException
	{
		
		int iFlag = 0;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jforce","root","root");
			
			String q = "update admin set candidateName = ? where username = ?";
			
			PreparedStatement ps = conn.prepareStatement(q);
			
			ps.setString(1,CandName);
			ps.setString(2,us);
			
			iFlag = ps.executeUpdate();
			
			if(iFlag > 0)
			{
				return true;
			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
		
		
		
		
		
	}

	public boolean SaveData(String user, String pass, String mail, String phone) throws SQLException {
		int iFlag = 0;
		
		

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");

			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jforce", "root", "root");

			String q = "insert into admin values(?,?,?,?,?)";

			PreparedStatement ps = conn.prepareStatement(q);

			ps.setString(1, user);
			ps.setString(2, pass);
			ps.setString(3, mail);
			ps.setString(4, phone);
			ps.setString(5, null);

			iFlag = ps.executeUpdate();

			if (iFlag > 0) {
				return true;
			}

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;

	}

	public boolean LogingData1(String us, String pas) throws SQLException
	{
		boolean iFlag = false;
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jforce","root","root");
			
			
			String q = "select * from admin where username = ? and password = ?";
			
			PreparedStatement ps = conn.prepareStatement(q);
			
			ps.setString(1, us);
			ps.setString(2, pas);
			
			ResultSet rs = ps.executeQuery();
			
			iFlag = rs.next();
						
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return iFlag;
		
		
		
		
	}
	

}
