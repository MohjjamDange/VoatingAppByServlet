package com.friend;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class candListData
 */
@WebServlet("/candListData")
public class candListData extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
    /**
     * @see HttpServlet#HttpServlet()
     */
	
	
    public candListData() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		PrintWriter ps = response.getWriter();
		
		
		
		String str = request.getParameter("votBut");
		String userName = request.getParameter("us");
		Datadb dobj = new Datadb();
		
		countsDb db = new countsDb(str);
		
		int iCnt = 0;
		
		
		
		
		try {
			if(dobj.chkNull(str))
			{
				if(dobj.updateData(userName,str))
				{
					iCnt++;
					if(db.updateCount(iCnt))
					{
						System.out.println("Count Succesfully Updated");
					}
					else
					{
						System.out.println("Count Not updated");
					}
					
					
					System.out.println("Voat Succesfully Saved");
					
					response.sendRedirect("ThankYou.html");
					ps.print("Voat Succesfully Saved...Thank You");
				}
				else
				{
					
					System.out.print("Voating Fail");
					ps.println("<h3>Voating Fail</h3>");
				}
				
			}
			else
			{
				System.out.println("User Already Voted");
				ps.print("<h3> User Already Voted</h3>");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
