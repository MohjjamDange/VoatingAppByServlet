package com.friend;

public class user {
	
	public String CandidateName;
	public int NumberOfVotes;
	
	public user(String candidateName, int numberOfVotes) {
		super();
		CandidateName = candidateName;
		NumberOfVotes = numberOfVotes;
	}
	
		


	public user() {
		super();
	}


	public String getCandidateName() {
		return CandidateName;
	}
	public void setCandidateName(String candidateName) {
		CandidateName = candidateName;
	}
	public int getNumberOfVotes() {
		return NumberOfVotes;
	}
	public void setNumberOfVotes(int numberOfVotes) {
		NumberOfVotes = numberOfVotes;
	}
	
	
	@Override
	public String toString() {
		return "user [CandidateName=" + CandidateName + ", NumberOfVotes=" + NumberOfVotes + ", getCandidateName()="
				+ getCandidateName() + ", getNumberOfVotes()=" + getNumberOfVotes() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

	
	
	
	
	
	
	

}
