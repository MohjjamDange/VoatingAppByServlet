package com.friend;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mysql.cj.x.protobuf.MysqlxPrepare.Prepare;
import com.service.user;

public class countsDb {
	
	public String candName;
	
	public countsDb() {
		super();
	}



	public countsDb(String str)
	{
		this.candName = str;
		
	}
	
	
	
	public List<user> getDataDisplay()throws  SQLException
	{
		List<user> Data = new ArrayList<>();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jforce","root","root");
			
			String q = "select * from counts";
			
			PreparedStatement ps =  conn.prepareStatement(q);
			
			ResultSet rs =  ps.executeQuery();
			
			while(rs.next())
			{
				user us = new user();
				
				us.setCandidateName(rs.getString(2));
				
				us.setNumberOfVotes(rs.getInt(3));
				
				Data.add(us);
							
				
			}
			
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Data;
		
		
		
		
		
	}
	
	public boolean updateCount(int iCnt) throws SQLException
	{
		int iFlag = 0;
		int iSum = 0;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jforce","root","root");
			
			String q = "select * from counts";
			
		//	Statement stmt = conn.createStatement();
			
			PreparedStatement pst = conn.prepareStatement(q);
			
			
			ResultSet rs = pst.executeQuery(q);
			while(rs.next())
			{
				if(candName.equals(rs.getString(2) ))
				{
					
					
					iSum =(rs.getInt(3)) + iCnt;
					
					break;
													
				}
				
			}
			
			
			String s = String.valueOf(iSum);
			
			
			
			String p = "update counts set NumberOfVotes = ? where CandidateName = ?";
			
			PreparedStatement ps = conn.prepareStatement(p);
			
			
			
			ps.setString(1,s);
			ps.setString(2,candName);
			
			iFlag = ps.executeUpdate();
			
			if(iFlag > 0)
			{
				return true;
			}
			
				
			
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
		
		
	}

}
